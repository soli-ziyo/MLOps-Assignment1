# Summary of 2_Default_Xgboost

[<< Go back](../README.md)


## Extreme Gradient Boosting (Xgboost)
- **n_jobs**: -1
- **objective**: multi:softprob
- **eta**: 0.075
- **max_depth**: 6
- **min_child_weight**: 1
- **subsample**: 1.0
- **colsample_bytree**: 1.0
- **eval_metric**: mlogloss
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: kfold
 - **k_folds**: 5
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

5470.9 seconds

### Metric details
|           |          1 |          2 |          3 |          4 |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.998778 |   0.966543 |   0.949939 |   0.980769 |   0.974054 |    0.974007 |       0.974007 | 0.0768136 |
| recall    |   0.997558 |   0.952381 |   0.949939 |   0.996337 |   0.974054 |    0.974054 |       0.974054 | 0.0768136 |
| f1-score  |   0.998167 |   0.95941  |   0.949939 |   0.988492 |   0.974054 |    0.974002 |       0.974002 | 0.0768136 |
| support   | 819        | 819        | 819        | 819        |   0.974054 | 3276        |    3276        | 0.0768136 |


## Confusion matrix
|              |   Predicted as 1 |   Predicted as 2 |   Predicted as 3 |   Predicted as 4 |
|:-------------|-----------------:|-----------------:|-----------------:|-----------------:|
| Labeled as 1 |              817 |                2 |                0 |                0 |
| Labeled as 2 |                1 |              780 |               38 |                0 |
| Labeled as 3 |                0 |               25 |              778 |               16 |
| Labeled as 4 |                0 |                0 |                3 |              816 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)

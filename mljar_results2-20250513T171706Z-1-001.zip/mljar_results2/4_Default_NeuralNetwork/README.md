# Summary of 4_Default_NeuralNetwork

[<< Go back](../README.md)


## Neural Network
- **n_jobs**: -1
- **dense_1_size**: 32
- **dense_2_size**: 16
- **learning_rate**: 0.05
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: kfold
 - **k_folds**: 5
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

4443.0 seconds

### Metric details
|           |          1 |          2 |          3 |          4 |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.991474 |   0.871795 |   0.850404 |   0.899415 |   0.904151 |    0.903272 |       0.903272 |  0.739799 |
| recall    |   0.993895 |   0.913309 |   0.770452 |   0.93895  |   0.904151 |    0.904151 |       0.904151 |  0.739799 |
| f1-score  |   0.992683 |   0.892069 |   0.808456 |   0.918757 |   0.904151 |    0.902991 |       0.902991 |  0.739799 |
| support   | 819        | 819        | 819        | 819        |   0.904151 | 3276        |    3276        |  0.739799 |


## Confusion matrix
|              |   Predicted as 1 |   Predicted as 2 |   Predicted as 3 |   Predicted as 4 |
|:-------------|-----------------:|-----------------:|-----------------:|-----------------:|
| Labeled as 1 |              814 |                3 |                2 |                0 |
| Labeled as 2 |                1 |              748 |               66 |                4 |
| Labeled as 3 |                6 |              100 |              631 |               82 |
| Labeled as 4 |                0 |                7 |               43 |              769 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)

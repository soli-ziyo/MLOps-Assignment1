# AutoML Leaderboard

| Best model   | name                                                         | model_type     | metric_type   |   metric_value |   train_time |   single_prediction_time |
|:-------------|:-------------------------------------------------------------|:---------------|:--------------|---------------:|-------------:|-------------------------:|
|              | [1_Default_LightGBM](1_Default_LightGBM/README.md)           | LightGBM       | logloss       |      0.0817836 |      5788.74 |                1505.48   |
| **the best** | [2_Default_Xgboost](2_Default_Xgboost/README.md)             | Xgboost        | logloss       |      0.0768136 |      5472.71 |                1554.82   |
|              | [3_Default_CatBoost](3_Default_CatBoost/README.md)           | CatBoost       | logloss       |      0.0907232 |     10678    |                   0.5736 |
|              | [4_Default_NeuralNetwork](4_Default_NeuralNetwork/README.md) | Neural Network | logloss       |      0.739799  |      4444.84 |                1542.58   |

### AutoML Performance
![AutoML Performance](ldb_performance.png)

### AutoML Performance Boxplot
![AutoML Performance Boxplot](ldb_performance_boxplot.png)

### Features Importance
![features importance across models](features_heatmap.png)



### Spearman Correlation of Models
![models spearman correlation](correlation_heatmap.png)


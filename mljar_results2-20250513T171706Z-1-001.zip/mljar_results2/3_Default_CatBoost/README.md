# Summary of 3_Default_CatBoost

[<< Go back](../README.md)


## CatBoost
- **n_jobs**: -1
- **learning_rate**: 0.15
- **depth**: 5
- **rsm**: 1
- **loss_function**: MultiClass
- **eval_metric**: MultiClass
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: kfold
 - **k_folds**: 5
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

10675.9 seconds

### Metric details
|           |          1 |          2 |          3 |          4 |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.996346 |   0.95936  |   0.94932  |   0.977218 |   0.970696 |    0.970561 |       0.970561 | 0.0907232 |
| recall    |   0.998779 |   0.95116  |   0.937729 |   0.995116 |   0.970696 |    0.970696 |       0.970696 | 0.0907232 |
| f1-score  |   0.997561 |   0.955242 |   0.943489 |   0.986086 |   0.970696 |    0.970595 |       0.970595 | 0.0907232 |
| support   | 819        | 819        | 819        | 819        |   0.970696 | 3276        |    3276        | 0.0907232 |


## Confusion matrix
|              |   Predicted as 1 |   Predicted as 2 |   Predicted as 3 |   Predicted as 4 |
|:-------------|-----------------:|-----------------:|-----------------:|-----------------:|
| Labeled as 1 |              818 |                1 |                0 |                0 |
| Labeled as 2 |                3 |              779 |               37 |                0 |
| Labeled as 3 |                0 |               32 |              768 |               19 |
| Labeled as 4 |                0 |                0 |                4 |              815 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)

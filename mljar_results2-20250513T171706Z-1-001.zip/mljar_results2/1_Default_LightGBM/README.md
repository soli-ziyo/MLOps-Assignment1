# Summary of 1_Default_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: multiclass
- **num_leaves**: 63
- **learning_rate**: 0.05
- **feature_fraction**: 0.9
- **bagging_fraction**: 0.9
- **min_data_in_leaf**: 10
- **metric**: multi_logloss
- **custom_eval_metric_name**: None
- **num_class**: 4
- **explain_level**: 2

## Validation
 - **validation_type**: kfold
 - **k_folds**: 5
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

5786.9 seconds

### Metric details
|           |          1 |          2 |          3 |          4 |   accuracy |   macro avg |   weighted avg |   logloss |
|:----------|-----------:|-----------:|-----------:|-----------:|-----------:|------------:|---------------:|----------:|
| precision |   0.998778 |   0.966584 |   0.948905 |   0.983092 |   0.974359 |    0.97434  |       0.97434  | 0.0817836 |
| recall    |   0.997558 |   0.953602 |   0.952381 |   0.993895 |   0.974359 |    0.974359 |       0.974359 | 0.0817836 |
| f1-score  |   0.998167 |   0.960049 |   0.95064  |   0.988464 |   0.974359 |    0.97433  |       0.97433  | 0.0817836 |
| support   | 819        | 819        | 819        | 819        |   0.974359 | 3276        |    3276        | 0.0817836 |


## Confusion matrix
|              |   Predicted as 1 |   Predicted as 2 |   Predicted as 3 |   Predicted as 4 |
|:-------------|-----------------:|-----------------:|-----------------:|-----------------:|
| Labeled as 1 |              817 |                2 |                0 |                0 |
| Labeled as 2 |                1 |              781 |               37 |                0 |
| Labeled as 3 |                0 |               25 |              780 |               14 |
| Labeled as 4 |                0 |                0 |                5 |              814 |

## Learning curves
![Learning curves](learning_curves.png)

## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Precision Recall Curve

![Precision Recall Curve](precision_recall_curve.png)



[<< Go back](../README.md)
